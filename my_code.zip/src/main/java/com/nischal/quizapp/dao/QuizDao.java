package com.nischal.quizapp.dao;

import com.nischal.quizapp.model.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuizDao extends JpaRepository<Integer, Quiz> {
}
